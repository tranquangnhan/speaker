<?php
    require_once "hanghoa.php";
    require_once "loaihang.php";
?>
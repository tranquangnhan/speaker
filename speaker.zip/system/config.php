<?php
define('HOST_DB','remotemysql.com');
define('NAME_DB','7zeE9DbecU');
define('USER_DB','7zeE9DbecU');
define('PASS_DB','2fIyWXy9QL');
define('ROOT_URL','');
define('ADMIN_URL',ROOT_URL.'/admin');
define('SITE_URL',ROOT_URL.'/site/');
define('SYSTEM_PATH',ROOT_URL.'/system');
define('PATH_IMG_ADMIN','../uploads/');
define('PAGE_SIZE',3);
define('BASE_URL','');
//  Username: 7zeE9DbecU

// Database name: 7zeE9DbecU

// Password: 2fIyWXy9QL

// Server: remotemysql.com

// Port: 3306 


// Database:	tytbblab_namspeaker
// Host:	localhost
// Username:	tytbblab_nam
// Password:	Tranquangnhan@1606


?>
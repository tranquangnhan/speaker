<?php
$pathimg = '../uploads/';
$pathimgsite ='../uploads/';
?>